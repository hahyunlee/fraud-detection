import pickle
#from flask import Flask, render_template, request, jsonify, Response
import pandas as pd
import requests
from pymongo import MongoClient
import time
from main import *
import numpy as np


#app = Flask(__name__)


def trained_model_outputs(model, json_string):
    # X = pipeline(json_string)
    probability = np.random.uniform()
    if probability < .5:
        prediction = 'Green'
    elif probability < .8:
        prediction = 'Yellow'
    else:
        prediction = 'Red'
    # probability = model.predicted_proba(X)[0][1]
    # prediction = model.predict(X)
    return probability, prediction


if __name__ == '__main__':
    #app.run(host='0.0.0.0', port=3333, debug=True)
    # unpickle
    with open('model.pkl', 'rb') as f:
    model = pickle.load(f)
    hi_threshold = .95
    sequence_number = 0
    client = MongoClient('mongodb://localhost:27017/')
    db = client['testing_fraud']
    api_key = 'vYm9mTUuspeyAWH1v-acfoTlck-tCxwTw9YfCynC'
    url = 'https://hxobin8em5.execute-api.us-west-2.amazonaws.com/api/'
    while True:
        response = requests.post(
            url, json={'api_key': api_key, 'sequence_number': sequence_number})
        raw_data = response.json()
        if raw_data['_next_sequence_number'] != sequence_number:
            sequence_number = raw_data['_next_sequence_number']
            probability, prediction = trained_model_outputs(
                raw_data['data'][0], model)
            if prediction == 1:
                raw_data['data'][0]['prediction'] = 'Yellow'
                if probability > hi_threshold:
                    raw_data['data'][0]['prediction'] = 'Red'
            else:
                raw_data['data'][0]['prediction'] = 'Green'
            raw_data['data'][0]['probability'] = probability
            #df = pd.DataFrame.from_dict(raw_data['data'][0],orient = 'index').T
            db.collection.insert_one(raw_data['data'][0])
        #print(sequence_number, raw_data['data'][0].keys())
        time.sleep(120)
